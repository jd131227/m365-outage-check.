<#
.SYNOPSIS
  When Microsoft 365 (Outlook / Teams / SharePoint / OneDrive / Copilot) is not working, tell
  read-only whether the cause is a Microsoft-side outage or our side (PC / network).

.DESCRIPTION
  1. Control test: can this PC reach the internet at all (Windows' own connectivity check URL)
  2. HTTPS request to each service's front door; read the response code (uses the PC's proxy settings)
  3. This PC: are Outlook / Teams / OneDrive running, is there an Outlook offline cache (.ost)
  Only the front door (before sign-in) is checked. Even when the front door answers, the mailbox
  behind it can still be down, so confirm on Microsoft's status page / Service health in the admin center.
  Changes nothing. Writes only the result file (.txt) in -OutDir. No admin rights needed.
  Runs in Windows PowerShell 5.1 and PowerShell 7.

  Exit codes: 0 = front doors OK / 1 = Microsoft side suspected / 2 = our side suspected / 3 = script error

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File M365-OutageCheck.ps1
  powershell -ExecutionPolicy Bypass -File M365-OutageCheck.ps1 -RepeatMinutes 10   # re-check every 10 min (Ctrl+C to stop)
  powershell -ExecutionPolicy Bypass -File M365-OutageCheck.ps1 -NoFile             # screen only
#>
[CmdletBinding()]
param(
    [string]$SharePointHost,                       # e.g. contoso.sharepoint.com (default: detected from OneDrive settings)
    [int]$TimeoutSec = 10,
    [int]$RepeatMinutes = 0,                       # 0 = run once
    [string]$OutDir = (Join-Path $env:TEMP 'm365-check'),
    [switch]$NoFile
)

$ErrorActionPreference = 'Stop'
# Allow TLS 1.2 on PCs with old defaults (this process only; OS settings are not changed)
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }

$StatusLinks = [ordered]@{
    'Public status (anyone)'          = 'https://status.cloud.microsoft'
    'Service health (admins only)'    = 'https://admin.microsoft.com/#/servicehealth'
    'Microsoft 365 Status (X)'        = 'https://x.com/MSFT365Status'
}

function Find-TenantHosts {
    # Take only the tenant's SharePoint / OneDrive host names from the OneDrive (work) settings
    # (the full URL contains the user's name, so it is not used)
    try {
        foreach ($k in @(Get-ChildItem 'HKCU:\Software\Microsoft\OneDrive\Accounts' -ErrorAction Stop | Where-Object { $_.PSChildName -like 'Business*' })) {
            $u = (Get-ItemProperty $k.PSPath -ErrorAction SilentlyContinue).ServiceEndpointUri
            if ($u) {
                $od = ([uri]$u).Host                       # e.g. contoso-my.sharepoint.com
                return @{ OneDrive = $od; SharePoint = ($od -replace '-my\.sharepoint\.com$', '.sharepoint.com') }
            }
        }
    } catch { }
    return $null
}

function Test-TlsPhase([string]$HostName) {
    # Find the stage that fails: TCP connect -> TLS handshake (also reads the certificate issuer)
    $c = New-Object System.Net.Sockets.TcpClient
    try {
        $ar = $c.BeginConnect($HostName, 443, $null, $null)
        if (-not ($ar.AsyncWaitHandle.WaitOne($TimeoutSec * 1000) -and $c.Connected)) { return @{ Stage = 'TCP connect failed'; Issuer = '' } }
        $c.EndConnect($ar)
        # Accept any certificate and read only its issuer (so an inspection device's certificate is shown too; no data is sent)
        $ssl = New-Object System.Net.Security.SslStream($c.GetStream(), $false, { $true })
        $ssl.ReadTimeout = $TimeoutSec * 1000; $ssl.WriteTimeout = $TimeoutSec * 1000
        try { $ssl.AuthenticateAsClient($HostName) } catch { return @{ Stage = 'TLS dropped mid-handshake (server closed the connection)'; Issuer = '' } }
        $iss = if ($ssl.RemoteCertificate) { ($ssl.RemoteCertificate.Issuer -split ',')[0] -replace '^CN=', '' } else { '' }
        return @{ Stage = 'TLS OK (no HTTP response)'; Issuer = $iss }
    } catch { return @{ Stage = 'check failed'; Issuer = '' } } finally { $c.Close() }
}

function Test-Endpoint([string]$Name, [string]$Url) {
    # GET the front door before sign-in and look only at the response code (redirects are not followed)
    $u = [uri]$Url
    $code = $null; $err = $null
    $sw = [Diagnostics.Stopwatch]::StartNew()
    try {
        $req = [System.Net.HttpWebRequest]::Create($Url)
        $req.Method = 'GET'
        $req.AllowAutoRedirect = $false
        $req.Timeout = $TimeoutSec * 1000
        $req.ReadWriteTimeout = $TimeoutSec * 1000
        $req.UserAgent = 'M365-OutageCheck/1.0'
        if ($req.Proxy) { $req.Proxy.Credentials = [System.Net.CredentialCache]::DefaultCredentials }   # for authenticating proxies
        $resp = $req.GetResponse()
        $code = [int]$resp.StatusCode
        $resp.Close()
    } catch {
        # Unwrap the WebException from the exception PowerShell wraps around it
        $ex = $_.Exception
        while ($ex -and -not ($ex -is [System.Net.WebException]) -and $ex.InnerException) { $ex = $ex.InnerException }
        if ($ex -is [System.Net.WebException]) {
            if ($ex.Response) { $code = [int]$ex.Response.StatusCode; $ex.Response.Close() } else { $err = [string]$ex.Status }
        } else { $err = $ex.Message }
    }
    $sw.Stop()

    if ($null -ne $code) {
        $resp = "HTTP $code"
        if     ($code -eq 429) { $j = 'Microsoft side (throttled)' }
        elseif ($code -ge 500) { $j = 'Microsoft side error' }
        elseif ($code -eq 407) { $j = 'Our side (proxy auth)' }
        else                   { $j = 'OK' }               # 200 / 302 / 401 / 403 = the front door is answering
    } else {
        $resp = $err
        switch -Regex ($err) {
            '^Timeout$'                    { $j = 'Timeout'; break }
            '^NameResolutionFailure$'      { $j = 'Our side (DNS)'; break }
            '^ProxyNameResolutionFailure$' { $j = 'Our side (proxy)'; break }
            '^(TrustFailure|SecureChannelFailure)$' { $j = 'Our side (certificate/TLS)'; break }
            default                        { $j = 'No connection' }
        }
        # No response: find out which stage stops (HTTPS only)
        if ($u.Scheme -eq 'https' -and $j -in @('Timeout', 'No connection')) {
            $t = Test-TlsPhase $u.Host
            $resp = "$resp -> $($t.Stage)"
        }
    }
    [pscustomobject][ordered]@{ Item = $Name; Host = $u.Host; Response = $resp; Judgment = $j; Seconds = [math]::Round($sw.Elapsed.TotalSeconds, 1) }
}

function Get-ClientState {
    # This PC's state (read only). .ost file names contain the mail address, so they are not shown
    $procs = [ordered]@{ 'OUTLOOK' = 'Outlook (classic)'; 'olk' = 'new Outlook'; 'ms-teams' = 'Teams (new)'; 'Teams' = 'Teams (classic)'; 'OneDrive' = 'OneDrive' }
    $running = @()
    foreach ($p in $procs.Keys) { if (Get-Process -Name $p -ErrorAction SilentlyContinue) { $running += $procs[$p] } }
    $osts = @(Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Microsoft\Outlook') -Filter '*.ost' -ErrorAction SilentlyContinue)
    $sizeGB = 0
    if ($osts.Count -gt 0) { $sizeGB = [math]::Round((($osts | Measure-Object Length -Sum).Sum) / 1GB, 2) }
    [ordered]@{
        'Running'            = $(if ($running.Count) { $running -join ', ' } else { '(none)' })
        'OST files'          = $osts.Count
        'OST total GB'       = $sizeGB
        'OST last written'   = $(if ($osts.Count) { ($osts | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime.ToString('yyyy-MM-dd HH:mm') } else { '-' })
        'New Outlook only'   = [bool]((Get-Process -Name 'olk' -ErrorAction SilentlyContinue) -and -not (Get-Process -Name 'OUTLOOK' -ErrorAction SilentlyContinue))
    }
}

function Invoke-Round {
    $targets = New-Object System.Collections.Generic.List[object]
    $targets.Add(@('Internet (control)', 'http://www.msftconnecttest.com/connecttest.txt'))
    $targets.Add(@('Sign-in (Entra ID)', 'https://login.microsoftonline.com/common/v2.0/.well-known/openid-configuration'))
    $targets.Add(@('Mail (Exchange / Outlook)', 'https://outlook.office365.com/owa/'))
    $targets.Add(@('Teams', 'https://teams.microsoft.com/'))
    $targets.Add(@('Microsoft 365 / Copilot', 'https://m365.cloud.microsoft/'))
    $hosts = Find-TenantHosts
    $spHost = if ($SharePointHost) { $SharePointHost } elseif ($hosts) { $hosts.SharePoint } else { $null }
    if ($spHost) { $targets.Add(@('SharePoint', "https://$spHost/")) }
    if ($hosts -and $hosts.OneDrive) { $targets.Add(@('OneDrive', "https://$($hosts.OneDrive)/")) }

    $results = @(foreach ($t in $targets) { Test-Endpoint $t[0] $t[1] })
    $ctrl = $results[0]
    $ms = @($results | Select-Object -Skip 1)

    # Inspection-device check: is a working Microsoft front door's certificate issued by something other than a public CA
    $iss = (Test-TlsPhase 'login.microsoftonline.com').Issuer
    $inspect = ($iss -and $iss -notmatch 'DigiCert|Microsoft|GlobalSign|Baltimore')

    # Verdict: control NG -> our side / signs of our side -> our side / 5xx, 429, timeout, no connection -> Microsoft side / else front doors OK
    if ($ctrl.Judgment -ne 'OK') {
        $code = 2; $verdict = 'Our side suspected: this PC cannot reach the internet at all (LAN / Wi-Fi / VPN / proxy). Run pc-check.ps1, then hand to Network'
    } elseif (@($ms | Where-Object { $_.Judgment -like 'Our side*' }).Count) {
        $code = 2; $verdict = 'Our side suspected: failing at Microsoft name resolution / proxy / certificate. Hand to Network (check whether other PCs see the same)'
    } elseif (@($ms | Where-Object { $_.Judgment -ne 'OK' }).Count) {
        $code = 1; $verdict = 'Microsoft-side outage likely: the internet works but a Microsoft front door fails. Do not change PC settings; check the status page.' +
            "`r`n         To confirm: turn off Wi-Fi on a phone and open the same service (e.g. outlook.office.com) on mobile data -> if it also fails, it is Microsoft"
    } else {
        $code = 0; $verdict = 'Front doors OK: no problem on our side. If it still does not work, the service fails after sign-in -> check the status page'
    }
    if ($inspect) {
        $verdict += "`r`n         Note: Microsoft's certificate is issued by '$iss'. An inspection device may sit in the path -> ask Network to check our side too"
    }
    [pscustomobject]@{ Time = Get-Date; Results = $results; Verdict = $verdict; Code = $code; Client = (Get-ClientState); Issuer = $iss }
}

function Format-Round($r) {
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add(('=== Microsoft 365 outage check  {0:yyyy-MM-dd HH:mm:ss}  {1} ===' -f $r.Time, $env:COMPUTERNAME))
    $lines.Add('')
    $lines.Add("Verdict: $($r.Verdict)")
    $lines.Add('')
    $lines.Add('[Service front doors]')
    foreach ($x in $r.Results) { $lines.Add(('  {0,-4} {1}  {2}  ({3} / {4} s)' -f $(if ($x.Judgment -eq 'OK') { 'OK' } else { 'NG' }), $x.Item, $x.Judgment, $x.Response, $x.Seconds)) }
    $lines.Add(('  (Microsoft certificate issuer: {0})' -f $(if ($r.Issuer) { $r.Issuer } else { 'not retrieved' })))
    $lines.Add('')
    $lines.Add('[This PC]')
    foreach ($k in $r.Client.Keys) { $lines.Add(('  {0}: {1}' -f $k, $r.Client[$k])) }
    $lines.Add('')
    $lines.Add('[During an outage: do / do not]')
    if ($r.Client['OST files'] -gt 0) {
        $lines.Add('  - Outlook cache found: mail and calendar already received can be read offline. Keep Outlook open.')
    }
    if ($r.Client['New Outlook only']) {
        $lines.Add('  - The new Outlook can show only a limited amount offline. Use the phone for anything urgent.')
    }
    $lines.Add('  - Do NOT: delete the .ost / rebuild the Outlook profile / repair or reinstall Office / change passwords / sign in again and again')
    $lines.Add('  - Ignore calls or mail from "Microsoft support" and links asking you to "sign in again"; report them to the helpdesk')
    $lines.Add('')
    $lines.Add('[Official status]')
    foreach ($k in $StatusLinks.Keys) { $lines.Add(('  {0}: {1}' -f $k, $StatusLinks[$k])) }
    $lines -join "`r`n"
}

try {
    $logFile = $null
    if (-not $NoFile) {
        if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }
        $logFile = Join-Path $OutDir ('m365-check_{0}_{1:yyyyMMdd_HHmmss}.txt' -f $env:COMPUTERNAME, (Get-Date))
    }
    $bom = New-Object System.Text.UTF8Encoding($true)       # BOM so Notepad / Excel open it correctly
    $first = $true
    do {
        if (-not $first) { Start-Sleep -Seconds ($RepeatMinutes * 60) }
        $r = Invoke-Round
        if ($first) {
            $text = Format-Round $r
            Write-Host $text
            if ($logFile) { [IO.File]::AppendAllText($logFile, $text + "`r`n", $bom) }
            if ($RepeatMinutes -gt 0) { Write-Host ''; Write-Host "Re-checking every $RepeatMinutes min (Ctrl+C to stop)" -ForegroundColor Cyan }
        } else {
            # From the second round on, one line (only the failing items)
            $ng = @($r.Results | Where-Object { $_.Judgment -ne 'OK' } | ForEach-Object { "$($_.Item)=$($_.Response)" })
            $line = ('{0:HH:mm:ss}  exit code {1}  {2}' -f $r.Time, $r.Code, $(if ($ng.Count) { 'NG: ' + ($ng -join ' / ') } else { 'all front doors OK' }))
            Write-Host $line
            if ($logFile) { [IO.File]::AppendAllText($logFile, $line + "`r`n", $bom) }
        }
        $first = $false
    } while ($RepeatMinutes -gt 0)

    if ($logFile) { Write-Host ''; Write-Host "Saved to: $logFile (send this file to the helpdesk)" -ForegroundColor Cyan }
    exit $r.Code
}
catch {
    Write-Host ('Error: ' + $_.Exception.Message) -ForegroundColor Red
    exit 3
}
