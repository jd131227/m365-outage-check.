@echo off
rem Microsoft 365 outage self-check. Read-only: changes nothing on this PC.
cls
title Microsoft 365 check
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0M365-OutageCheck.ps1"
echo.
pause
